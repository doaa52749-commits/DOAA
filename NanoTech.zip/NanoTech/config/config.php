<?php

declare(strict_types=1);

const APP_NAME = 'Nano Tech';
const APP_BASE_URL = '';

const DB_HOST = '127.0.0.1';
const DB_NAME = 'nanotech';
const DB_USER = 'root';
const DB_PASS = '';

